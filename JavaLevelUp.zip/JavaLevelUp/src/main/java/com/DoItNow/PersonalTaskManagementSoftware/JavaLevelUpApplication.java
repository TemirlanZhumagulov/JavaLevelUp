package com.DoItNow.PersonalTaskManagementSoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaLevelUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaLevelUpApplication.class, args);
	}
}
