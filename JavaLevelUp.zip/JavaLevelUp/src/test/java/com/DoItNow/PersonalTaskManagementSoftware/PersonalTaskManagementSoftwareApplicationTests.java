package com.DoItNow.PersonalTaskManagementSoftware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalTaskManagementSoftwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
